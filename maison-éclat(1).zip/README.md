# Maison Éclat - Enterprise E-Commerce Platform

A premium luxury e-commerce platform built with React, Node.js, Prisma, and Stripe.

## Tech Stack
- **Frontend**: React (Vite) + TypeScript + TailwindCSS + Shadcn UI
- **Backend**: Node.js + Express
- **Database**: PostgreSQL + Prisma ORM
- **Caching**: Redis
- **Payments**: Stripe
- **Auth**: JWT + HttpOnly Cookies

## Getting Started

### Prerequisites
- Node.js 20+
- Docker & Docker Compose

### Setup
1. Clone the repository
2. Copy `.env.example` to `.env` and fill in the secrets
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the infrastructure:
   ```bash
   docker-compose up -d
   ```
5. Run migrations and seed the database:
   ```bash
   npx prisma migrate dev
   npm run prisma:seed
   ```
6. Start the development server:
   ```bash
   npm run dev
   ```

## Features
- **Luxury Aesthetic**: Premium UI design with smooth animations.
- **Secure Auth**: JWT-based authentication with RBAC.
- **Stripe Integration**: Secure checkout and webhook handling.
- **Admin Dashboard**: Full management of products, categories, and orders.
- **Performance**: Redis caching for high-traffic routes.

## Deployment
The project includes a multi-stage Dockerfile for production-ready deployment.
```bash
docker build -t maison-eclat .
```
