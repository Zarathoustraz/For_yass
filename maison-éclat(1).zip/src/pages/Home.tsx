import React from "react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";
import { ArrowRight, ShieldCheck, Truck, Sparkles } from "lucide-react";

const Home = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden bg-stone-900">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/luxury/1920/1080?blur=2" 
            alt="Hero" 
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60" />
        </div>

        <div className="container relative z-10 px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <span className="text-xs font-bold uppercase tracking-[0.3em] mb-6 block text-stone-300">
              Est. 1924 • Paris
            </span>
            <h1 className="text-5xl md:text-8xl font-serif tracking-tighter mb-8 leading-[0.9]">
              Timeless <br /> <span className="italic">Elegance</span>
            </h1>
            <p className="max-w-xl mx-auto text-lg text-stone-300 mb-10 font-light leading-relaxed">
              Discover our curated collection of artisanal fragrances and premium accessories, crafted for those who appreciate the finer things in life.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/products">
                <Button size="lg" className="rounded-full px-10 py-7 text-sm uppercase tracking-widest font-bold bg-white text-black hover:bg-stone-200">
                  Shop Collection
                </Button>
              </Link>
              <Link to="/about">
                <Button variant="outline" size="lg" className="rounded-full px-10 py-7 text-sm uppercase tracking-widest font-bold border-white text-white hover:bg-white/10">
                  Our Heritage
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16">
            <div className="max-w-xl">
              <h2 className="text-3xl md:text-5xl font-serif tracking-tight mb-6">The Curated Selection</h2>
              <p className="text-stone-500 font-light">Explore our most sought-after categories, each representing a unique facet of the Maison Éclat identity.</p>
            </div>
            <Link to="/products" className="group flex items-center space-x-2 text-xs font-bold uppercase tracking-widest mt-8 md:mt-0">
              <span>View All</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Fragrances", img: "https://picsum.photos/seed/perfume/800/1000", delay: 0.1 },
              { name: "Skincare", img: "https://picsum.photos/seed/skincare/800/1000", delay: 0.2 },
              { name: "Accessories", img: "https://picsum.photos/seed/watch/800/1000", delay: 0.3 },
            ].map((cat) => (
              <motion.div
                key={cat.name}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: cat.delay }}
                viewport={{ once: true }}
                className="group relative aspect-[3/4] overflow-hidden rounded-2xl bg-stone-100"
              >
                <img 
                  src={cat.img} 
                  alt={cat.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                  <h3 className="text-2xl font-serif mb-4">{cat.name}</h3>
                  <Link to={`/products?category=${cat.name.toLowerCase()}`}>
                    <Button variant="outline" className="rounded-full border-white text-white hover:bg-white hover:text-black opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0">
                      Explore
                    </Button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-20 bg-stone-50 border-y border-stone-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div className="flex flex-col items-center">
              <div className="h-12 w-12 rounded-full bg-stone-200 flex items-center justify-center mb-6">
                <ShieldCheck className="h-6 w-6 text-stone-700" />
              </div>
              <h4 className="text-sm font-bold uppercase tracking-widest mb-2">Secure Payment</h4>
              <p className="text-xs text-stone-500 font-light">Industry-standard encryption for your peace of mind.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="h-12 w-12 rounded-full bg-stone-200 flex items-center justify-center mb-6">
                <Truck className="h-6 w-6 text-stone-700" />
              </div>
              <h4 className="text-sm font-bold uppercase tracking-widest mb-2">Global Delivery</h4>
              <p className="text-xs text-stone-500 font-light">Complimentary shipping on all orders over $500.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="h-12 w-12 rounded-full bg-stone-200 flex items-center justify-center mb-6">
                <Sparkles className="h-6 w-6 text-stone-700" />
              </div>
              <h4 className="text-sm font-bold uppercase tracking-widest mb-2">Authenticity</h4>
              <p className="text-xs text-stone-500 font-light">Every piece is guaranteed original and certified.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
