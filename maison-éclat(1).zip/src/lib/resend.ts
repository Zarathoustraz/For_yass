import { Resend } from "resend";
import { env } from "./env";

const resend = env.RESEND_API_KEY ? new Resend(env.RESEND_API_KEY) : null;

export const sendOrderConfirmation = async (email: string, orderId: string, total: number) => {
  if (!resend) return;

  try {
    await resend.emails.send({
      from: "Maison Éclat <orders@maisoneclat.com>",
      to: email,
      subject: `Order Confirmation #${orderId.slice(-8).toUpperCase()}`,
      html: `
        <div style="font-family: serif; max-width: 600px; margin: 0 auto; padding: 40px; border: 1px solid #e5e5e5; border-radius: 24px;">
          <h1 style="text-align: center; letter-spacing: -0.05em;">MAISON ÉCLAT</h1>
          <p style="text-align: center; text-transform: uppercase; font-size: 10px; letter-spacing: 0.2em; color: #888;">Thank you for your purchase</p>
          <hr style="margin: 30px 0; border: 0; border-top: 1px solid #eee;" />
          <p>Your order <strong>#${orderId.slice(-8).toUpperCase()}</strong> has been confirmed.</p>
          <p>Total Amount: <strong>$${total.toLocaleString()}</strong></p>
          <p style="margin-top: 40px; font-size: 12px; color: #888;">We are preparing your pieces with the utmost care. You will receive another update once your order has shipped.</p>
        </div>
      `,
    });
  } catch (error) {
    console.error("Failed to send email", error);
  }
};

export default resend;
