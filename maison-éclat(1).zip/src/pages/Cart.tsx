import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../hooks/useCart";
import { useAuth } from "../hooks/useAuth";
import { Button } from "../components/ui/button";
import { Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import api from "../services/api";
import { toast } from "sonner";

const Cart = () => {
  const { items, refreshCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const total = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleCheckout = async () => {
    if (!user) {
      toast.error("Please login to checkout");
      navigate("/login");
      return;
    }

    try {
      const orderRes = await api.post("/orders");
      const checkoutRes = await api.post("/checkout/create-session", { orderId: orderRes.data.id });
      window.location.href = checkoutRes.data.url;
    } catch (error: any) {
      toast.error(error.response?.data?.error || "Checkout failed");
    }
  };

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <div className="max-w-md mx-auto space-y-8">
          <div className="h-24 w-24 rounded-full bg-stone-50 flex items-center justify-center mx-auto">
            <ShoppingBag className="h-10 w-10 text-stone-300" />
          </div>
          <h1 className="text-3xl font-serif tracking-tight">Your cart is empty</h1>
          <p className="text-stone-500 font-light">It seems you haven't added any pieces to your collection yet.</p>
          <Link to="/products">
            <Button className="rounded-full px-10 py-7 text-sm uppercase tracking-widest font-bold mt-8">
              Explore Collection
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-serif tracking-tight mb-12">Shopping Cart</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2 space-y-8">
          {items.map((item) => (
            <div key={item.id} className="flex gap-6 pb-8 border-b border-stone-100 group">
              <div className="h-32 w-24 rounded-xl overflow-hidden bg-stone-50 flex-shrink-0">
                <img 
                  src={item.product.images[0] || "https://picsum.photos/seed/product/400/500"} 
                  alt={item.product.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-grow flex flex-col justify-between py-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-medium text-stone-900 mb-1">{item.product.name}</h3>
                    <p className="text-sm font-serif text-stone-500">${item.product.price.toLocaleString()}</p>
                  </div>
                  <Button variant="ghost" size="icon" className="text-stone-300 hover:text-red-500">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center border border-stone-200 rounded-full px-4 py-1">
                    <button className="text-stone-400 hover:text-stone-900">-</button>
                    <span className="mx-4 text-sm font-medium">{item.quantity}</span>
                    <button className="text-stone-400 hover:text-stone-900">+</button>
                  </div>
                  <p className="text-sm font-bold tracking-widest uppercase">
                    ${(item.product.price * item.quantity).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-stone-50 rounded-3xl p-8 sticky top-24">
            <h2 className="text-xl font-serif mb-8">Order Summary</h2>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-sm">
                <span className="text-stone-500">Subtotal</span>
                <span>${total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-stone-500">Shipping</span>
                <span className="text-green-600 uppercase text-[10px] font-bold tracking-widest">Complimentary</span>
              </div>
              <div className="pt-4 border-t border-stone-200 flex justify-between items-end">
                <span className="text-sm font-bold uppercase tracking-widest">Total</span>
                <span className="text-2xl font-serif">${total.toLocaleString()}</span>
              </div>
            </div>
            <Button 
              className="w-full rounded-full py-8 text-sm uppercase tracking-widest font-bold flex items-center justify-center group"
              onClick={handleCheckout}
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <p className="text-[10px] text-center text-stone-400 mt-6 uppercase tracking-widest">
              Secure checkout by Stripe
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
