import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter } from "../ui/card";
import { Button } from "../ui/button";
import { ShoppingCart, Eye } from "lucide-react";
import { useCart } from "../../hooks/useCart";
import { toast } from "sonner";

interface Product {
  id: string;
  name: string;
  price: number;
  images: string[];
  category: { name: string };
}

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const { addItem } = useCart();

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      await addItem(product.id, 1);
      toast.success(`${product.name} added to cart`);
    } catch (error) {
      toast.error("Failed to add item to cart");
    }
  };

  return (
    <Card className="group overflow-hidden border-none bg-transparent transition-all duration-300">
      <Link to={`/product/${product.id}`}>
        <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-stone-100">
          <img 
            src={product.images[0] || "https://picsum.photos/seed/product/800/1000"} 
            alt={product.name} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
          
          <div className="absolute bottom-4 left-4 right-4 flex gap-2 translate-y-12 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
            <Button 
              className="flex-grow rounded-full bg-white text-black hover:bg-stone-200 text-[10px] uppercase font-bold tracking-widest"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="mr-2 h-3 w-3" />
              Add to Cart
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-full border-white text-white hover:bg-white hover:text-black"
            >
              <Eye className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Link>
      <CardContent className="pt-6 px-0">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-stone-400 font-bold mb-1">
              {product.category.name}
            </p>
            <h3 className="text-sm font-medium text-stone-900 group-hover:text-primary transition-colors">
              {product.name}
            </h3>
          </div>
          <p className="text-sm font-serif text-stone-600">
            ${product.price.toLocaleString()}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;
