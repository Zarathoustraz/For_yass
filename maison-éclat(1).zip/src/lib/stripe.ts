import Stripe from "stripe";
import { env } from "./env";

let stripe: Stripe | null = null;

if (env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-01-27.acacia" as any,
  });
}

export default stripe;
