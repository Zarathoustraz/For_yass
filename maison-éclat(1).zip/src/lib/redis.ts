import Redis from "ioredis";
import logger from "./logger";

let redis: Redis | null = null;

try {
  if (process.env.REDIS_URL) {
    redis = new Redis(process.env.REDIS_URL);
    redis.on("error", (err) => logger.error(err, "Redis Error"));
  }
} catch (error) {
  logger.warn("Redis connection failed, caching disabled.");
}

export const getCache = async (key: string) => {
  if (!redis) return null;
  const data = await redis.get(key);
  return data ? JSON.parse(data) : null;
};

export const setCache = async (key: string, value: any, ttl: number = 3600) => {
  if (!redis) return;
  await redis.set(key, JSON.stringify(value), "EX", ttl);
};

export const delCache = async (key: string) => {
  if (!redis) return;
  await redis.del(key);
};

export default redis;
