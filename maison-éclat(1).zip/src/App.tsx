import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import { CartProvider, useCart } from "./hooks/useCart";
import { ShoppingCart, User, LogOut, Menu, X, Search } from "lucide-react";
import { Button } from "./components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./components/ui/sheet";
import { Toaster } from "./components/ui/sonner";
import Home from "./pages/Home";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Cart from "./pages/Cart";
import Orders from "./pages/Orders";
import AdminDashboard from "./pages/AdminDashboard";

const Navbar = () => {
  const { user, logout } = useAuth();
  const { items } = useCart();
  const navigate = useNavigate();

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="text-2xl font-serif tracking-tighter text-primary">
          MAISON ÉCLAT
        </Link>

        <div className="hidden md:flex items-center space-x-8 text-sm font-medium uppercase tracking-widest">
          <Link to="/products" className="hover:text-primary transition-colors">Collection</Link>
          <Link to="/about" className="hover:text-primary transition-colors">Heritage</Link>
          <Link to="/stores" className="hover:text-primary transition-colors">Boutiques</Link>
        </div>

        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="hidden sm:flex">
            <Search className="h-5 w-5" />
          </Button>

          <Link to="/cart">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {items.length > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">
                  {items.length}
                </span>
              )}
            </Button>
          </Link>

          {user ? (
            <div className="flex items-center space-x-2">
              <Link to={user.role === "ADMIN" ? "/admin" : "/profile"}>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </Link>
              <Button variant="ghost" size="icon" onClick={() => logout()}>
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          ) : (
            <Link to="/login">
              <Button variant="outline" className="hidden sm:flex rounded-full px-6">Login</Button>
            </Link>
          )}

          <Sheet>
            <SheetTrigger
              render={
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              }
            />
            <SheetContent side="right">
              <SheetHeader>
                <SheetTitle className="font-serif text-2xl">MAISON ÉCLAT</SheetTitle>
              </SheetHeader>
              <div className="flex flex-col space-y-4 mt-8 uppercase tracking-widest text-sm font-medium">
                <Link to="/products">Collection</Link>
                <Link to="/about">Heritage</Link>
                <Link to="/stores">Boutiques</Link>
                {!user && <Link to="/login">Login</Link>}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
};

const Footer = () => (
  <footer className="border-top bg-stone-50 py-16">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-4">
          <h3 className="font-serif text-xl tracking-tighter">MAISON ÉCLAT</h3>
          <p className="text-sm text-stone-500 leading-relaxed">
            Crafting timeless elegance since 1924. Our commitment to excellence defines every piece in our collection.
          </p>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-widest mb-6">Collection</h4>
          <ul className="space-y-3 text-sm text-stone-500">
            <li><Link to="/products?category=fragrance">Fragrances</Link></li>
            <li><Link to="/products?category=skincare">Skincare</Link></li>
            <li><Link to="/products?category=accessories">Accessories</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-widest mb-6">Maison</h4>
          <ul className="space-y-3 text-sm text-stone-500">
            <li><Link to="/about">Our Story</Link></li>
            <li><Link to="/sustainability">Sustainability</Link></li>
            <li><Link to="/careers">Careers</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-widest mb-6">Newsletter</h4>
          <p className="text-sm text-stone-500 mb-4">Join our inner circle for exclusive updates.</p>
          <div className="flex space-x-2">
            <input 
              type="email" 
              placeholder="Email address" 
              className="bg-transparent border-b border-stone-300 py-2 text-sm focus:outline-none focus:border-primary w-full"
            />
            <Button variant="ghost" className="uppercase text-[10px] tracking-widest font-bold">Join</Button>
          </div>
        </div>
      </div>
      <div className="mt-16 pt-8 border-t border-stone-200 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-widest text-stone-400">
        <p>© 2026 MAISON ÉCLAT. All rights reserved.</p>
        <div className="flex space-x-6 mt-4 md:mt-0">
          <Link to="/privacy">Privacy Policy</Link>
          <Link to="/terms">Terms of Service</Link>
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Router>
          <div className="min-h-screen flex flex-col bg-white text-stone-900 font-sans selection:bg-stone-900 selection:text-white">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/products" element={<Products />} />
                <Route path="/product/:id" element={<ProductDetail />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/cart" element={<Cart />} />
                <Route path="/orders" element={<Orders />} />
                <Route path="/admin/*" element={<AdminDashboard />} />
              </Routes>
            </main>
            <Footer />
            <Toaster position="top-center" />
          </div>
        </Router>
      </CartProvider>
    </AuthProvider>
  );
}
