import express from "express";
import prisma from "../lib/prisma";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const dbStatus = await prisma.$queryRaw`SELECT 1`.then(() => "up").catch(() => "down");
    // Add Redis check if needed
    
    res.json({
      status: "ok",
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      services: {
        database: dbStatus,
      }
    });
  } catch (error) {
    res.status(500).json({ status: "error", message: "Health check failed" });
  }
});

export default router;
