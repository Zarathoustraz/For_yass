import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // Clear existing data
  await prisma.cartItem.deleteMany();
  await prisma.cart.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.review.deleteMany();
  await prisma.product.deleteMany();
  await prisma.category.deleteMany();
  await prisma.user.deleteMany();

  // Create Admin
  const adminPassword = await bcrypt.hash("admin123", 10);
  await prisma.user.create({
    data: {
      email: "admin@maisoneclat.com",
      password: adminPassword,
      name: "Maison Admin",
      role: "ADMIN",
    },
  });

  // Create Categories
  const fragrance = await prisma.category.create({ data: { name: "Fragrances" } });
  const skincare = await prisma.category.create({ data: { name: "Skincare" } });
  const accessories = await prisma.category.create({ data: { name: "Accessories" } });

  // Create Products
  const products = [
    {
      name: "L'Essence de Nuit",
      description: "A mysterious and seductive fragrance with notes of black orchid, sandalwood, and rare spices. Housed in a hand-blown crystal flacon.",
      price: 245.00,
      stock: 50,
      categoryId: fragrance.id,
      images: ["https://picsum.photos/seed/perfume1/800/1000"],
    },
    {
      name: "Or Blanc Serum",
      description: "Infused with 24k gold particles and rare botanical extracts, this serum revitalizes and illuminates the complexion with unparalleled radiance.",
      price: 380.00,
      stock: 30,
      categoryId: skincare.id,
      images: ["https://picsum.photos/seed/skincare1/800/1000"],
    },
    {
      name: "Midnight Silk Scarf",
      description: "Hand-rolled edges and 100% pure mulberry silk. Featuring an exclusive hand-painted celestial motif inspired by the Parisian night sky.",
      price: 185.00,
      stock: 100,
      categoryId: accessories.id,
      images: ["https://picsum.photos/seed/scarf1/800/1000"],
    },
    {
      name: "Céleste Eau de Parfum",
      description: "A light, airy fragrance capturing the essence of a spring morning in the Tuileries Garden. Notes of white lily, pear, and musk.",
      price: 195.00,
      stock: 75,
      categoryId: fragrance.id,
      images: ["https://picsum.photos/seed/perfume2/800/1000"],
    },
  ];

  for (const product of products) {
    await prisma.product.create({ data: product });
  }

  console.log("Database seeded successfully.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
