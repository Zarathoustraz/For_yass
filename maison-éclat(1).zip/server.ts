import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import { requestLogger, secureHeaders, authMiddleware, adminMiddleware } from "./src/middleware";
import prisma from "./src/lib/prisma";
import { hashPassword, comparePassword } from "./src/lib/auth/password";
import { signToken } from "./src/lib/auth/jwt";
import { handleError, ValidationError, AuthError } from "./src/lib/errors";
import stripe from "./src/lib/stripe";
import healthRouter from "./src/routes/health";
import { sendOrderConfirmation } from "./src/lib/resend";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());
  app.use(requestLogger);
  app.use(secureHeaders);

  // API routes
  app.use("/api/health", healthRouter);

  // Auth routes
  app.post("/api/auth/register", async (req, res, next) => {
    try {
      const { email, password, name } = req.body;
      if (!email || !password) throw new ValidationError("Email and password required");

      const existingUser = await prisma.user.findUnique({ where: { email } });
      if (existingUser) throw new ValidationError("User already exists");

      const hashedPassword = await hashPassword(password);
      const user = await prisma.user.create({
        data: { email, password: hashedPassword, name },
      });

      const token = signToken({ id: user.id, email: user.email, role: user.role });
      res.cookie("token", token, { httpOnly: true, secure: process.env.NODE_ENV === "production" });
      res.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/auth/login", async (req, res, next) => {
    try {
      const { email, password } = req.body;
      const user = await prisma.user.findUnique({ where: { email } });
      if (!user || !(await comparePassword(password, user.password))) {
        throw new AuthError("Invalid credentials");
      }

      const token = signToken({ id: user.id, email: user.email, role: user.role });
      res.cookie("token", token, { httpOnly: true, secure: process.env.NODE_ENV === "production" });
      res.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie("token");
    res.json({ message: "Logged out" });
  });

  app.get("/api/auth/me", authMiddleware, async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: (req as any).user.id } });
    res.json({ user: { id: user?.id, email: user?.email, name: user?.name, role: user?.role } });
  });

  // Product routes
  app.get("/api/products", async (req, res, next) => {
    try {
      const { category, search, sort } = req.query;
      const where: any = {};
      if (category) where.categoryId = category;
      if (search) where.name = { contains: search as string, mode: "insensitive" };

      const orderBy: any = {};
      if (sort === "price_asc") orderBy.price = "asc";
      else if (sort === "price_desc") orderBy.price = "desc";
      else orderBy.createdAt = "desc";

      const products = await prisma.product.findMany({
        where,
        orderBy,
        include: { category: true },
      });
      res.json(products);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/products/:id", async (req, res, next) => {
    try {
      const product = await prisma.product.findUnique({
        where: { id: req.params.id },
        include: { category: true, reviews: { include: { user: true } } },
      });
      if (!product) throw new ValidationError("Product not found");
      res.json(product);
    } catch (error) {
      next(error);
    }
  });

  // Admin Product CRUD
  app.post("/api/admin/products", authMiddleware, adminMiddleware, async (req, res, next) => {
    try {
      const { name, description, price, images, stock, categoryId } = req.body;
      const product = await prisma.product.create({
        data: { name, description, price, images, stock, categoryId },
      });
      res.json(product);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/admin/products/:id", authMiddleware, adminMiddleware, async (req, res, next) => {
    try {
      const product = await prisma.product.update({
        where: { id: req.params.id },
        data: req.body,
      });
      res.json(product);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/admin/products/:id", authMiddleware, adminMiddleware, async (req, res, next) => {
    try {
      await prisma.product.delete({ where: { id: req.params.id } });
      res.json({ message: "Product deleted" });
    } catch (error) {
      next(error);
    }
  });

  // Category routes
  app.get("/api/categories", async (req, res, next) => {
    try {
      const categories = await prisma.category.findMany();
      res.json(categories);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/admin/categories", authMiddleware, adminMiddleware, async (req, res, next) => {
    try {
      const { name } = req.body;
      const category = await prisma.category.create({ data: { name } });
      res.json(category);
    } catch (error) {
      next(error);
    }
  });

  // Cart routes
  app.get("/api/cart", authMiddleware, async (req, res, next) => {
    try {
      const userId = (req as any).user.id;
      let cart = await prisma.cart.findUnique({
        where: { userId },
        include: { items: { include: { product: true } } },
      });
      if (!cart) {
        cart = await prisma.cart.create({
          data: { userId },
          include: { items: { include: { product: true } } },
        });
      }
      res.json(cart);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/cart/items", authMiddleware, async (req, res, next) => {
    try {
      const userId = (req as any).user.id;
      const { productId, quantity } = req.body;
      const cart = await prisma.cart.findUnique({ where: { userId } });
      if (!cart) throw new ValidationError("Cart not found");

      const existingItem = await prisma.cartItem.findFirst({
        where: { cartId: cart.id, productId },
      });

      if (existingItem) {
        await prisma.cartItem.update({
          where: { id: existingItem.id },
          data: { quantity: existingItem.quantity + quantity },
        });
      } else {
        await prisma.cartItem.create({
          data: { cartId: cart.id, productId, quantity },
        });
      }
      res.json({ message: "Item added to cart" });
    } catch (error) {
      next(error);
    }
  });

  // Order routes
  app.post("/api/orders", authMiddleware, async (req, res, next) => {
    try {
      const userId = (req as any).user.id;
      const cart = await prisma.cart.findUnique({
        where: { userId },
        include: { items: { include: { product: true } } },
      });

      if (!cart || cart.items.length === 0) throw new ValidationError("Cart is empty");

      const total = cart.items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

      const order = await prisma.order.create({
        data: {
          userId,
          total,
          items: {
            create: cart.items.map((item) => ({
              productId: item.productId,
              quantity: item.quantity,
              price: item.product.price,
            })),
          },
        },
      });

      // Clear cart
      await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });

      res.json(order);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/orders", authMiddleware, async (req, res, next) => {
    try {
      const userId = (req as any).user.id;
      const orders = await prisma.order.findMany({
        where: { userId },
        include: { items: { include: { product: true } } },
        orderBy: { createdAt: "desc" },
      });
      res.json(orders);
    } catch (error) {
      next(error);
    }
  });

  // Stripe routes
  app.post("/api/checkout/create-session", authMiddleware, async (req, res, next) => {
    try {
      if (!stripe) throw new Error("Stripe not configured");
      const { orderId } = req.body;
      const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: { items: { include: { product: true } } },
      });

      if (!order) throw new ValidationError("Order not found");

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: order.items.map((item) => ({
          price_data: {
            currency: "usd",
            product_data: {
              name: item.product.name,
              description: item.product.description,
            },
            unit_amount: Math.round(item.price * 100),
          },
          quantity: item.quantity,
        })),
        mode: "payment",
        success_url: `${process.env.APP_URL}/order/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.APP_URL}/cart`,
        metadata: { orderId: order.id },
      });

      await prisma.order.update({
        where: { id: order.id },
        data: { stripeId: session.id },
      });

      res.json({ url: session.url });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
    if (!stripe) return res.status(400).send("Stripe not configured");
    const sig = req.headers["stripe-signature"] as string;
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err: any) {
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as any;
      const orderId = session.metadata.orderId;

      const order = await prisma.order.update({
        where: { id: orderId },
        data: { status: "PAID" },
        include: { user: true, items: true },
      });

      if (order) {
        // Send confirmation email
        await sendOrderConfirmation(order.user.email, order.id, order.total);

        // Update stock
        for (const item of order.items) {
          await prisma.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } },
          });
        }
      }
    }

    res.json({ received: true });
  });

  // Error handler
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    const { message, statusCode, code } = handleError(err);
    res.status(statusCode).json({ error: message, code });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
