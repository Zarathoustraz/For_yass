import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/api";
import { useCart } from "../hooks/useCart";
import { Button } from "../components/ui/button";
import { Skeleton } from "../components/ui/skeleton";
import { ShoppingCart, Heart, Share2, ShieldCheck, Truck, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const { addItem } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await api.get(`/products/${id}`);
        setProduct(res.data);
      } catch (error) {
        console.error("Failed to fetch product", error);
        toast.error("Product not found");
        navigate("/products");
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = async () => {
    try {
      await addItem(product.id, quantity);
      toast.success(`${product.name} added to cart`);
    } catch (error) {
      toast.error("Failed to add item to cart");
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          <Skeleton className="aspect-[4/5] w-full rounded-3xl" />
          <div className="space-y-8">
            <Skeleton className="h-4 w-1/4" />
            <Skeleton className="h-12 w-3/4" />
            <Skeleton className="h-6 w-1/2" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-16 w-full rounded-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div className="aspect-[4/5] rounded-3xl overflow-hidden bg-stone-50">
            <img 
              src={product.images[0] || "https://picsum.photos/seed/product/1200/1500"} 
              alt={product.name} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="aspect-square rounded-xl overflow-hidden bg-stone-100 cursor-pointer hover:opacity-80 transition-opacity">
                <img 
                  src={`https://picsum.photos/seed/product-${i}/400/400`} 
                  alt="Thumbnail" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <div className="mb-8">
            <p className="text-xs font-bold uppercase tracking-[0.3em] text-stone-400 mb-4">
              {product.category.name}
            </p>
            <h1 className="text-4xl md:text-5xl font-serif tracking-tight mb-4">{product.name}</h1>
            <p className="text-2xl font-serif text-stone-600">${product.price.toLocaleString()}</p>
          </div>

          <div className="prose prose-stone max-w-none mb-10">
            <p className="text-stone-500 font-light leading-relaxed">
              {product.description}
            </p>
          </div>

          <div className="space-y-6 mb-12">
            <div className="flex items-center space-x-4">
              <div className="flex items-center border border-stone-200 rounded-full px-6 py-3">
                <button 
                  className="text-stone-400 hover:text-stone-900 px-2"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  -
                </button>
                <span className="mx-6 text-sm font-bold min-w-[20px] text-center">{quantity}</span>
                <button 
                  className="text-stone-400 hover:text-stone-900 px-2"
                  onClick={() => setQuantity(quantity + 1)}
                >
                  +
                </button>
              </div>
              <Button 
                className="flex-grow rounded-full py-7 text-sm uppercase tracking-widest font-bold"
                onClick={handleAddToCart}
              >
                <ShoppingCart className="mr-2 h-4 w-4" />
                Add to Cart
              </Button>
              <Button variant="outline" size="icon" className="rounded-full h-14 w-14 border-stone-200">
                <Heart className="h-5 w-5" />
              </Button>
            </div>
            <Button variant="ghost" className="text-[10px] uppercase tracking-widest font-bold text-stone-400 flex items-center">
              <Share2 className="mr-2 h-3 w-3" />
              Share this piece
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-stone-100">
            <div className="flex items-center space-x-3">
              <Truck className="h-5 w-5 text-stone-400" />
              <span className="text-[10px] uppercase tracking-widest font-bold text-stone-500">Free Shipping</span>
            </div>
            <div className="flex items-center space-x-3">
              <RefreshCw className="h-5 w-5 text-stone-400" />
              <span className="text-[10px] uppercase tracking-widest font-bold text-stone-500">30-Day Returns</span>
            </div>
            <div className="flex items-center space-x-3">
              <ShieldCheck className="h-5 w-5 text-stone-400" />
              <span className="text-[10px] uppercase tracking-widest font-bold text-stone-500">2-Year Warranty</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
