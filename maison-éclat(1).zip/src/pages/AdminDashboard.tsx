import React, { useState, useEffect } from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import api from "../services/api";
import { 
  LayoutDashboard, 
  Package, 
  List, 
  ShoppingCart, 
  Users, 
  Settings,
  Plus,
  Pencil,
  Trash2
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { toast } from "sonner";

const AdminOverview = () => {
  const [stats, setStats] = useState({ products: 0, orders: 0, users: 0, revenue: 0 });

  useEffect(() => {
    // Mock stats for now
    setStats({ products: 24, orders: 156, users: 892, revenue: 124500 });
  }, []);

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-serif tracking-tight">Dashboard Overview</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: "Total Revenue", value: `$${stats.revenue.toLocaleString()}`, icon: LayoutDashboard },
          { label: "Products", value: stats.products, icon: Package },
          { label: "Orders", value: stats.orders, icon: ShoppingCart },
          { label: "Members", value: stats.users, icon: Users },
        ].map((stat) => (
          <Card key={stat.label} className="border-none shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-[10px] uppercase tracking-widest font-bold text-stone-400">
                {stat.label}
              </CardTitle>
              <stat.icon className="h-4 w-4 text-stone-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-serif">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

const AdminProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    try {
      const res = await api.get("/products");
      setProducts(res.data);
    } catch (error) {
      toast.error("Failed to fetch products");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-serif tracking-tight">Manage Collection</h1>
        <Button className="rounded-full px-6">
          <Plus className="mr-2 h-4 w-4" />
          New Piece
        </Button>
      </div>

      <Card className="border-none shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-stone-50">
            <TableRow>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold">Product</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold">Category</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold">Price</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold">Stock</TableHead>
              <TableHead className="text-[10px] uppercase tracking-widest font-bold text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product: any) => (
              <TableRow key={product.id}>
                <TableCell className="font-medium">{product.name}</TableCell>
                <TableCell>{product.category.name}</TableCell>
                <TableCell>${product.price.toLocaleString()}</TableCell>
                <TableCell>{product.stock}</TableCell>
                <TableCell className="text-right space-x-2">
                  <Button variant="ghost" size="icon"><Pencil className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" className="text-red-500"><Trash2 className="h-4 w-4" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

const AdminDashboard = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && (!user || user.role !== "ADMIN")) {
      toast.error("Access denied");
      navigate("/");
    }
  }, [user, loading, navigate]);

  if (loading) return null;

  return (
    <div className="flex min-h-[calc(100vh-64px)]">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-stone-50/50 p-6 space-y-8 hidden md:block">
        <div className="space-y-1">
          <p className="px-4 text-[10px] uppercase tracking-widest font-bold text-stone-400 mb-4">Management</p>
          <Link to="/admin">
            <Button variant="ghost" className="w-full justify-start rounded-xl">
              <LayoutDashboard className="mr-3 h-4 w-4" />
              Overview
            </Button>
          </Link>
          <Link to="/admin/products">
            <Button variant="ghost" className="w-full justify-start rounded-xl">
              <Package className="mr-3 h-4 w-4" />
              Collection
            </Button>
          </Link>
          <Link to="/admin/categories">
            <Button variant="ghost" className="w-full justify-start rounded-xl">
              <List className="mr-3 h-4 w-4" />
              Categories
            </Button>
          </Link>
          <Link to="/admin/orders">
            <Button variant="ghost" className="w-full justify-start rounded-xl">
              <ShoppingCart className="mr-3 h-4 w-4" />
              Orders
            </Button>
          </Link>
          <Link to="/admin/users">
            <Button variant="ghost" className="w-full justify-start rounded-xl">
              <Users className="mr-3 h-4 w-4" />
              Members
            </Button>
          </Link>
        </div>
        <div className="space-y-1">
          <p className="px-4 text-[10px] uppercase tracking-widest font-bold text-stone-400 mb-4">System</p>
          <Button variant="ghost" className="w-full justify-start rounded-xl">
            <Settings className="mr-3 h-4 w-4" />
            Settings
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-8 bg-white">
        <Routes>
          <Route path="/" element={<AdminOverview />} />
          <Route path="/products" element={<AdminProducts />} />
        </Routes>
      </main>
    </div>
  );
};

export default AdminDashboard;
