import React, { useState, useEffect } from "react";
import api from "../services/api";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Skeleton } from "../components/ui/skeleton";
import { ShoppingBag, Clock, CheckCircle2, Package, Truck, XCircle } from "lucide-react";

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await api.get("/orders");
        setOrders(res.data);
      } catch (error) {
        console.error("Failed to fetch orders", error);
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "PENDING": return <Clock className="h-4 w-4" />;
      case "PAID": return <CheckCircle2 className="h-4 w-4" />;
      case "SHIPPED": return <Package className="h-4 w-4" />;
      case "DELIVERED": return <Truck className="h-4 w-4" />;
      case "CANCELLED": return <XCircle className="h-4 w-4" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PENDING": return "bg-yellow-100 text-yellow-700";
      case "PAID": return "bg-green-100 text-green-700";
      case "SHIPPED": return "bg-blue-100 text-blue-700";
      case "DELIVERED": return "bg-stone-100 text-stone-700";
      case "CANCELLED": return "bg-red-100 text-red-700";
      default: return "";
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 space-y-8">
        <Skeleton className="h-12 w-1/4" />
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-48 w-full rounded-3xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-serif tracking-tight mb-12">Order History</h1>

      {orders.length === 0 ? (
        <div className="text-center py-24 bg-stone-50 rounded-3xl">
          <ShoppingBag className="h-12 w-12 text-stone-300 mx-auto mb-6" />
          <p className="text-stone-500 font-light">You haven't placed any orders yet.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {orders.map((order: any) => (
            <Card key={order.id} className="border-none shadow-sm rounded-3xl overflow-hidden">
              <CardHeader className="bg-stone-50 border-b border-stone-100 flex flex-row justify-between items-center py-6 px-8">
                <div className="flex gap-8">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest font-bold text-stone-400 mb-1">Order Placed</p>
                    <p className="text-sm font-medium">{new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest font-bold text-stone-400 mb-1">Total</p>
                    <p className="text-sm font-medium">${order.total.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest font-bold text-stone-400 mb-1">Order ID</p>
                    <p className="text-sm font-medium">#{order.id.slice(-8).toUpperCase()}</p>
                  </div>
                </div>
                <Badge className={`rounded-full px-4 py-1 flex items-center gap-2 border-none ${getStatusColor(order.status)}`}>
                  {getStatusIcon(order.status)}
                  <span className="text-[10px] uppercase tracking-widest font-bold">{order.status}</span>
                </Badge>
              </CardHeader>
              <CardContent className="p-8">
                <div className="space-y-6">
                  {order.items.map((item: any) => (
                    <div key={item.id} className="flex gap-6 items-center">
                      <div className="h-20 w-16 rounded-lg overflow-hidden bg-stone-100 flex-shrink-0">
                        <img 
                          src={item.product.images[0] || "https://picsum.photos/seed/product/200/250"} 
                          alt={item.product.name} 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="flex-grow">
                        <h4 className="text-sm font-medium">{item.product.name}</h4>
                        <p className="text-xs text-stone-500">Qty: {item.quantity}</p>
                      </div>
                      <p className="text-sm font-serif">${item.price.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Orders;
