# Agent Role & Goal

## Role
Senior Enterprise Software Architect and Full-Stack Engineer.

## Goal
Build a complete, deployable, secure, scalable e-commerce web application ready for production.

## Tech Stack
- **Frontend**: React (Vite) + TypeScript + TailwindCSS + Shadcn UI
- **Backend**: Node.js + Express (Full-stack architecture)
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: JWT + HttpOnly cookies + Role Based Access Control
- **Payments**: Stripe
- **Images**: Cloudinary
- **Email**: Resend
- **Caching**: Redis
- **Search**: Full-text search with PostgreSQL
- **Deployment**: Docker + Docker Compose

## Architecture
Clean architecture, modular folder structure, scalable patterns, and enterprise standards.

## Core Features
- **Public**: Landing page, Product catalog, Category filtering, Full-text search, Product page, Cart, Checkout with Stripe, User registration/login, Order history.
- **Admin Dashboard**: Product CRUD, Category CRUD, Order management, User management, Analytics dashboard, Image upload, Stock management.
- **Security**: Rate limiting, CSRF protection, Input validation (Zod), Secure headers, Password hashing (bcrypt), Role middleware.
- **Performance**: Server-side rendering (where applicable), Image optimization, Lazy loading, Redis caching, SEO optimized.
